import React, { useState } from "react";
import QRCode from "qrcode";

const Home = () => {
  const [subject, setSubject] = useState("");
  const [qrCodeURL, setQrCodeURL] = useState("");

  const generateQR = async () => {
    if (!subject) {
      alert("Please enter a subject name!");
      return;
    }

    let formBaseURL =
      "https://docs.google.com/forms/d/e/1FAIpQLSfJPTYzuj2XqlZZ0eU9m-3zk2B9huJgIlrW2e5PcESRtTDkEQ/viewform?usp=pp_url";

    let subjectEntryID = "entry.1146759780"; // Replace with actual entry ID from your Google Form

    let formLink = `${formBaseURL}&${subjectEntryID}=${encodeURIComponent(subject)}`;

    try {
      const qr = await QRCode.toDataURL(formLink);
      setQrCodeURL(qr);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    // Clear any authentication tokens if using localStorage/sessionStorage
    localStorage.removeItem("authToken"); // Remove token if stored
    sessionStorage.removeItem("authToken");

    // Redirect to login page
    window.location.href = "/login"; // Change this if your login route is different
  };

  return (
    <div
      style={{
        backgroundImage: `url("https://wallpaperaccess.com/full/5137774.jpg")`, // Replace with your image URL
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        color: "white",
        fontFamily: "'Poppins', sans-serif",
        textShadow: "2px 2px 8px rgba(0, 0, 0, 0.6)",
        position: "relative",
      }}
    >
      <h1 style={{ fontSize: "2.5rem", fontWeight: "bold", marginBottom: "10px" }}>
        📚 QR Attendance System
      </h1>

      <label htmlFor="subject" style={{ fontSize: "1.2rem", fontWeight: "500" }}>
        ✏️ Enter Subject Name:
      </label>

      <input
        type="text"
        id="subject"
        placeholder="Example: Mathematics"
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        required
        style={{
          padding: "12px",
          borderRadius: "10px",
          border: "1px solid #fff",
          width: "280px",
          marginBottom: "15px",
          backgroundColor: "rgba(255, 255, 255, 0.8)",
          fontSize: "1rem",
          color: "#333",
          textAlign: "center",
          outline: "none",
        }}
      />

      <button
        style={{
          backgroundColor: "#ff5733",
          color: "white",
          padding: "12px 25px",
          border: "none",
          borderRadius: "12px",
          cursor: "pointer",
          fontSize: "18px",
          fontWeight: "bold",
          transition: "0.3s",
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.3)",
        }}
        onClick={generateQR}
        onMouseOver={(e) => (e.target.style.backgroundColor = "#e74c3c")}
        onMouseOut={(e) => (e.target.style.backgroundColor = "#ff5733")}
      >
        🚀 Generate QR Code
      </button>

      {/* QR Code Display */}
      {qrCodeURL && (
        <div
          style={{
            marginTop: "20px",
            backgroundColor: "rgba(0, 0, 0, 0.7)",
            padding: "15px",
            borderRadius: "12px",
            boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.4)",
          }}
        >
          <h3 style={{ fontSize: "1.5rem", marginBottom: "10px", color: "#ffcc00" }}>
            📷 Scan This QR
          </h3>
          <img src={qrCodeURL} alt="QR Code" style={{ width: "250px", borderRadius: "8px" }} />
        </div>
      )}

      {/* Logout Button at the Bottom */}
      <button
        onClick={handleLogout}
        style={{
          position: "absolute",
          bottom: "20px",
          backgroundColor: "#ff3333",
          color: "white",
          padding: "12px 25px",
          border: "none",
          borderRadius: "12px",
          cursor: "pointer",
          fontSize: "16px",
          fontWeight: "bold",
          transition: "0.3s",
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.3)",
        }}
        onMouseOver={(e) => (e.target.style.backgroundColor = "#e60000")}
        onMouseOut={(e) => (e.target.style.backgroundColor = "#ff3333")}
      >
        🔒 Logout
      </button>
    </div>
  );
};

export default Home;
