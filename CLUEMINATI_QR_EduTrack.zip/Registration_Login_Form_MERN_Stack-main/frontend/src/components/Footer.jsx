export default function Footer() {
    return (
      <footer
        style={{
          backgroundColor: "#222",
          color: "#fff",
          textAlign: "center",
          padding: "15px 0",
          position: "fixed",
          width: "100%",
          bottom: "0",
          left: "0",
          right: "0",
          zIndex: "999",
          fontSize: "14px",
        }}
      >
        <p style={{ margin: "0" }}>© 2025 QR EduTrack. All Rights Reserved.</p>
      </footer>
    );
  }
  