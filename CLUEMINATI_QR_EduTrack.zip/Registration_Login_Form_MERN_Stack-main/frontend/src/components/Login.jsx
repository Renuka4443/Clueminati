import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from 'react';
import { Link } from "react-router-dom";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault();
        
        axios.post('http://localhost:3001/login', { email, password })
        .then(result => {
            console.log(result);
            if (result.data === "Success") {
                console.log("Login Success");
                alert('🎉 Login successful!');
                navigate('/home');
            } else {
                alert('❌ Incorrect password! Please try again.');
            }
        })
        .catch(err => console.log(err));
    };

    return (
        <div
            style={{
                backgroundImage: `url("https://wallpaperaccess.com/full/5137774.jpg")`, 
                backgroundSize: "cover",
                backgroundPosition: "center",
                backgroundRepeat: "no-repeat",
                height: "100vh",
                width: "100vw",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                textAlign: "center",
                fontFamily: "'Poppins', sans-serif",
            }}
        >
            <div
                className="p-5 rounded"
                style={{
                    width: "40%",
                    background: "linear-gradient(135deg, rgba(255,255,255,0.95), rgba(240,240,255,0.9))",
                    boxShadow: "0px 6px 18px rgba(0, 0, 0, 0.3)",
                    borderRadius: "15px",
                }}
            >
                <h2 className="mb-3" style={{ 
                    color: "#FF5733", 
                    fontWeight: "bold", 
                    textShadow: "1px 2px 6px rgba(0, 0, 0, 0.3)",
                    fontSize: "2rem"
                }}>
                     Login
                </h2>
                
                <form onSubmit={handleSubmit}>
                    <div className="mb-4 text-start">
                        <label htmlFor="email" className="form-label" style={{ fontWeight: "600", color: "#007BFF" }}>
                            📧 <strong>Email ID</strong>
                        </label>
                        <input 
                            type="email" 
                            placeholder="Enter Your Email"
                            className="form-control" 
                            id="email" 
                            onChange={(event) => setEmail(event.target.value)}
                            required
                            style={{
                                padding: "12px",
                                borderRadius: "10px",
                                border: "2px solid #FF5733",
                                fontSize: "1rem",
                                transition: "0.3s",
                            }}
                            onFocus={(e) => e.target.style.borderColor = "#28a745"}
                            onBlur={(e) => e.target.style.borderColor = "#FF5733"}
                        /> 
                    </div>

                    <div className="mb-4 text-start">
                        <label htmlFor="password" className="form-label" style={{ fontWeight: "600", color: "#28a745" }}>
                            🔑 <strong>Password</strong>
                        </label>
                        <input 
                            type="password" 
                            placeholder="Enter Your Password"
                            className="form-control" 
                            id="password" 
                            onChange={(event) => setPassword(event.target.value)}
                            required
                            style={{
                                padding: "12px",
                                borderRadius: "10px",
                                border: "2px solid #007BFF",
                                fontSize: "1rem",
                                transition: "0.3s",
                            }}
                            onFocus={(e) => e.target.style.borderColor = "#FF5733"}
                            onBlur={(e) => e.target.style.borderColor = "#007BFF"}
                        />
                    </div>

                    <button 
                        type="submit" 
                        className="btn w-100"
                        style={{
                            padding: "12px",
                            fontSize: "18px",
                            fontWeight: "bold",
                            borderRadius: "12px",
                            transition: "0.3s",
                            background: "linear-gradient(45deg, #FF5733, #ffbd69)",
                            color: "#fff",
                            border: "none",
                        }}
                        onMouseOver={(e) => e.target.style.background = "linear-gradient(45deg, #e74c3c, #f1c40f)"}
                        onMouseOut={(e) => e.target.style.background = "linear-gradient(45deg, #FF5733, #ffbd69)"}
                    >
                        Login Now
                    </button>
                </form>

                <p className="mt-4" style={{ fontWeight: "500", color: "#555", fontSize: "1.1rem" }}>
                    Don&apos;t have an account?
                </p>

                <Link 
                    to="/register" 
                    className="btn w-100"
                    style={{
                        padding: "12px",
                        fontSize: "18px",
                        fontWeight: "bold",
                        borderRadius: "12px",
                        transition: "0.3s",
                        background: "linear-gradient(45deg, #28a745, #20c997)",
                        color: "#fff",
                        border: "none",
                    }}
                    onMouseOver={(e) => e.target.style.background = "linear-gradient(45deg, #218838, #17a2b8)"}
                    onMouseOut={(e) => e.target.style.background = "linear-gradient(45deg, #28a745, #20c997)"}
                >
                    Register Now
                </Link>
            </div>
        </div>
    );
};

export default Login;
